const express = require('express')
const app = express()
const port = 6780

app.get('/', (req, res) => {
	res.send('index.html')
})

app.listen(port, () => {
  console.log(`Server listening on port ${port}`)
})